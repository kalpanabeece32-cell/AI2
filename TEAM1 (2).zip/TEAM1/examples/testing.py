from langchain_openai import ChatOpenAI, OpenAIEmbeddings
import httpx

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-gpt-35-turbo",
    api_key="sk-zkYSx0gbIE5r3A8xhFKeWw",  # Replace with your actual API key
    http_client=client
)
              
embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key="sk-20J3Dwzr9M1BquOqF-f4QA",  # Replace with your actual API key
    http_client=client
)



print(llm.invoke('hello').content)

#DON'T EDIT THIS FILE


# [SSLError] [SSL: CERTIFICATE_VERIFY_FAILED] 
# https://stackoverflow.com/questions/76106366/how-to-use-tiktoken-in-offline-mode-computer