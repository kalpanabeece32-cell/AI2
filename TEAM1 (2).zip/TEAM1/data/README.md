# DATA Assumptions

## 1. demographic_data.csv
Contains 25 locations across major US cities with:

- Population metrics (size, density, growth rate)
- Income levels (median household income)
- Education and employment statistics
- Homeownership rates and household characteristics
- 5-year growth trends

## 2. competitor_data.csv
Contains 50 competitor entries mapping to the locations with:

- Competitor names and types (Big Box, Grocery, Pharmacy, etc.)
- Store sizes and distances from location centers
- Daily traffic estimates
- Price points and customer ratings
- Parking availability

## 3. retail_performance_indicators.csv
Contains key retail metrics for each location:

- Foot traffic indices
- Commercial rent rates
- Vacancy rates and transaction values
- Transit accessibility and walkability scores
- Crime rates and nearby attractions
- Business climate scores

## 🎯 Usage Notes:
These files are designed to work together using the location_id as the common key. The data represents realistic scenarios for retail expansion analysis, including:
- Urban vs. suburban locations
- Various income demographics (from $52K to $125K median household income)
- Different competitor landscapes (from low to high competition)
- Diverse market conditions (growing vs. stable areas)