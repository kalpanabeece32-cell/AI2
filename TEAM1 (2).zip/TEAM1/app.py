"""
Streamlit LangChain Agent App

This app lets users create a LangChain agent with a custom system prompt, optionally upload files for embedding, and chat with the agent.

Security: API keys and model names are loaded from .env. All user inputs are validated. Sensitive data is never exposed.
"""

import os
import io
import logging
from typing import List, Optional
from dotenv import load_dotenv
import streamlit as st
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
import httpx
import requests  # For SSL error handling in process_embeddings

# Load environment variables
load_dotenv()
BASE_URL = os.getenv("BASE_URL")
AI_API_KEY = os.getenv("AI_API_KEY")
EMBEDDING_API_KEY = os.getenv("EMBEDDING_API_KEY")
AI_MODEL = os.getenv("AI_MODEL", "gpt-3.5-turbo")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-ada-002")

# HTTPS/SSL ERROR Workaround
tiktoken_cache_dir = "tiktoken_cache"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

# Create HTTP client (skip SSL verification if needed)
client = httpx.Client(verify=False)

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

# Streamlit page config
st.set_page_config(page_title="LangChain Agent App", layout="wide")
st.title("LangChain Agent Application")

# Session state initialization
if "agent" not in st.session_state:
    st.session_state.agent = None
if "agent_status" not in st.session_state:
    st.session_state.agent_status = "Not Ready"
if "vectorstore" not in st.session_state:
    st.session_state.vectorstore = None
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "agent_prompt" not in st.session_state:
    st.session_state.agent_prompt = None

# Sidebar: Agent creation
st.sidebar.header("Agent Setup")
agent_name = st.sidebar.text_input("Agent Name", max_chars=50)
ai_system_prompt = st.sidebar.text_area("AI System Prompt", height=150)
create_agent_btn = st.sidebar.button("Create Agent")

# Sidebar: File upload for embeddings
st.sidebar.header("Document Embedding (Optional)")
uploaded_files = st.sidebar.file_uploader(
    "Upload text files for embedding", type=["txt"], accept_multiple_files=True
)
embed_btn = st.sidebar.button("Process Embeddings")

# Agent status indicator
st.sidebar.markdown(f"**Agent Status:** {st.session_state.agent_status}")

# Helper functions
def validate_agent_inputs(name: str, prompt: str) -> Optional[str]:
    """Validate agent name and prompt."""
    if not name or not prompt:
        return "Agent name and system prompt are required."
    if len(name) > 50:
        return "Agent name too long."
    return None

def create_langchain_agent(name: str, prompt: str):
    """Create a LangChain agent with the given name and system prompt."""
    try:
        llm = ChatOpenAI(
            base_url=BASE_URL,
            model=AI_MODEL,
            api_key=AI_API_KEY,
            http_client=client,
        )
        # You may need to pass prompt in run() or as a prefix message
        # For now, store prompt in session state and use in chat
        logger.info(f"Agent '{name}' created successfully.")
        return llm, "Ready", prompt
    except Exception as e:
        logger.error(f"Error creating agent: {e}", exc_info=True)
        return None, f"Error: {str(e)}", None

def process_embeddings(files: List) -> Optional[FAISS]:
    """Process uploaded files and create a FAISS vectorstore.
    Handles SSL errors and unsupported embedding models gracefully.
    """
    try:
        # Validate embedding model
        supported_models = ["text-embedding-ada-002"]
        if EMBEDDING_MODEL not in supported_models:
            logger.error(f"Embedding model '{EMBEDDING_MODEL}' is not supported. Supported models: {supported_models}")
            st.sidebar.error(f"Embedding model '{EMBEDDING_MODEL}' is not supported. Please use one of: {supported_models}")
            return None
        docs = []
        for file in files:
            content = file.read().decode("utf-8")
            docs.append(Document(page_content=content, metadata={"source": file.name}))
        splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
        split_docs = splitter.split_documents(docs)
        embeddings = OpenAIEmbeddings(
            base_url=BASE_URL,
            model=EMBEDDING_MODEL,
            api_key=EMBEDDING_API_KEY,
            http_client=client,
        )
        vectorstore = FAISS.from_documents(split_docs, embeddings)
        logger.info("Documents embedded and vectorstore created.")
        return vectorstore
    except requests.exceptions.SSLError as ssl_err:
        logger.error(f"SSL error during embedding: {ssl_err}", exc_info=True)
        st.sidebar.error("SSL certificate verification failed. Please ensure your system's CA certificates are up to date. On Windows, run 'python -m pip install --upgrade certifi' and restart your app.")
        return None
    except KeyError as key_err:
        logger.error(f"Tokenizer mapping error: {key_err}", exc_info=True)
        st.sidebar.error(f"Tokenizer mapping error: {key_err}. Please use a supported embedding model.")
        return None
    except Exception as e:
        logger.error(f"Embedding error: {e}", exc_info=True)
        st.sidebar.error(f"Embedding error: {str(e)}")
        return None

# Agent creation logic
if create_agent_btn:
    error = validate_agent_inputs(agent_name, ai_system_prompt)
    if error:
        st.session_state.agent = None
        st.session_state.agent_status = f"Error: {error}"
        st.session_state.agent_prompt = None
    else:
        agent, status, agent_prompt = create_langchain_agent(agent_name, ai_system_prompt)
        st.session_state.agent = agent
        st.session_state.agent_status = status
        st.session_state.agent_prompt = agent_prompt

# Embedding logic
if embed_btn and uploaded_files:
    vectorstore = process_embeddings(uploaded_files)
    if vectorstore:
        st.session_state.vectorstore = vectorstore
        st.sidebar.success("Embeddings processed successfully.")
    else:
        st.sidebar.error("Failed to process embeddings.")

# Main chat area
st.header("Chat with Agent")
if st.session_state.agent_status == "Ready" and st.session_state.agent:
    user_input = st.text_input("Your message:")
    if st.button("Send") and user_input:
        try:
            context = ""
            if st.session_state.vectorstore:
                docs = st.session_state.vectorstore.similarity_search(user_input, k=2)
                context = "\n".join([d.page_content for d in docs])
            prompt = f"{st.session_state.agent_prompt}\nContext: {context}\nUser: {user_input}"
            response = st.session_state.agent.invoke(prompt).content
            st.session_state.chat_history.append((user_input, response))
        except Exception as e:
            logger.error(f"Chat error: {e}", exc_info=True)
            st.error(f"Agent error: {str(e)}")
    # Display chat history
    for i, (q, a) in enumerate(st.session_state.chat_history):
        st.markdown(f"**You:** {q}")
        st.markdown(f"**Agent:** {a}")
else:
    st.info("Create an agent to start chatting.")

# Usage Example
st.sidebar.markdown("""
**Usage Example:**
1. Enter agent name and system prompt, click 'Create Agent'.
2. (Optional) Upload text files and click 'Process Embeddings'.
3. Chat with the agent in the main area.
""")

# Security notes
st.sidebar.markdown("""
**Security:**
- API keys are loaded from .env
- Uploaded files are validated
- Sensitive data is never exposed
""")


# """
# Streamlit LangChain Agent App

# This app lets users create a LangChain agent with a custom system prompt, optionally upload files for embedding, and chat with the agent.

# Security: API keys and model names are loaded from .env. All user inputs are validated. Sensitive data is never exposed.
# """

# import os
# import io
# import logging
# from typing import List, Optional
# from dotenv import load_dotenv
# import streamlit as st
# import pandas as pd  # Added for tabular display
# from langchain_openai import ChatOpenAI, OpenAIEmbeddings
# from langchain_community.vectorstores import FAISS
# from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain_core.documents import Document
# import httpx
# import requests  # For SSL error handling in process_embeddings

# # Load environment variables
# load_dotenv()
# BASE_URL = os.getenv("BASE_URL")
# AI_API_KEY = os.getenv("AI_API_KEY")
# EMBEDDING_API_KEY = os.getenv("EMBEDDING_API_KEY")
# AI_MODEL = os.getenv("AI_MODEL", "gpt-3.5-turbo")
# EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-ada-002")

# # HTTPS/SSL ERROR Workaround
# tiktoken_cache_dir = "tiktoken_cache"
# os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

# # Create HTTP client (skip SSL verification if needed)
# client = httpx.Client(verify=False)

# # Configure logging
# logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
# logger = logging.getLogger(__name__)

# # Streamlit page config
# st.set_page_config(page_title="LangChain Agent App", layout="wide")
# st.title("LangChain Agent Application")

# # Session state initialization
# if "agent" not in st.session_state:
#     st.session_state.agent = None
# if "agent_status" not in st.session_state:
#     st.session_state.agent_status = "Not Ready"
# if "vectorstore" not in st.session_state:
#     st.session_state.vectorstore = None
# if "chat_history" not in st.session_state:
#     st.session_state.chat_history = []
# if "agent_prompt" not in st.session_state:
#     st.session_state.agent_prompt = None

# # Sidebar: Agent creation
# st.sidebar.header("Agent Setup")
# agent_name = st.sidebar.text_input("Agent Name", max_chars=50)
# ai_system_prompt = st.sidebar.text_area("AI System Prompt", height=150)
# create_agent_btn = st.sidebar.button("Create Agent")

# # Sidebar: File upload for embeddings
# st.sidebar.header("Document Embedding (Optional)")
# uploaded_files = st.sidebar.file_uploader(
#     "Upload text files for embedding", type=["txt"], accept_multiple_files=True
# )
# embed_btn = st.sidebar.button("Process Embeddings")

# # Agent status indicator
# st.sidebar.markdown(f"**Agent Status:** {st.session_state.agent_status}")

# # Helper functions
# def validate_agent_inputs(name: str, prompt: str) -> Optional[str]:
#     """Validate agent name and prompt."""
#     if not name or not prompt:
#         return "Agent name and system prompt are required."
#     if len(name) > 50:
#         return "Agent name too long."
#     return None

# def create_langchain_agent(name: str, prompt: str):
#     """Create a LangChain agent with the given name and system prompt."""
#     try:
#         llm = ChatOpenAI(
#             base_url=BASE_URL,
#             model=AI_MODEL,
#             api_key=AI_API_KEY,
#             http_client=client,
#         )
#         # You may need to pass prompt in run() or as a prefix message
#         # For now, store prompt in session state and use in chat
#         logger.info(f"Agent '{name}' created successfully.")
#         return llm, "Ready", prompt
#     except Exception as e:
#         logger.error(f"Error creating agent: {e}", exc_info=True)
#         return None, f"Error: {str(e)}", None

# def process_embeddings(files: List) -> Optional[FAISS]:
#     """Process uploaded files and create a FAISS vectorstore.
#     Handles SSL errors and unsupported embedding models gracefully.
#     """
#     try:
#         # Validate embedding model
#         supported_models = ["text-embedding-ada-002"]
#         if EMBEDDING_MODEL not in supported_models:
#             logger.error(f"Embedding model '{EMBEDDING_MODEL}' is not supported. Supported models: {supported_models}")
#             st.sidebar.error(f"Embedding model '{EMBEDDING_MODEL}' is not supported. Please use one of: {supported_models}")
#             return None
#         docs = []
#         for file in files:
#             content = file.read().decode("utf-8")
#             docs.append(Document(page_content=content, metadata={"source": file.name}))
#         splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
#         split_docs = splitter.split_documents(docs)
#         embeddings = OpenAIEmbeddings(
#             base_url=BASE_URL,
#             model=EMBEDDING_MODEL,
#             api_key=EMBEDDING_API_KEY,
#             http_client=client,
#         )
#         vectorstore = FAISS.from_documents(split_docs, embeddings)
#         logger.info("Documents embedded and vectorstore created.")
#         return vectorstore
#     except requests.exceptions.SSLError as ssl_err:
#         logger.error(f"SSL error during embedding: {ssl_err}", exc_info=True)
#         st.sidebar.error("SSL certificate verification failed. Please ensure your system's CA certificates are up to date. On Windows, run 'python -m pip install --upgrade certifi' and restart your app.")
#         return None
#     except KeyError as key_err:
#         logger.error(f"Tokenizer mapping error: {key_err}", exc_info=True)
#         st.sidebar.error(f"Tokenizer mapping error: {key_err}. Please use a supported embedding model.")
#         return None
#     except Exception as e:
#         logger.error(f"Embedding error: {e}", exc_info=True)
#         st.sidebar.error(f"Embedding error: {str(e)}")
#         return None

# # Agent creation logic
# if create_agent_btn:
#     error = validate_agent_inputs(agent_name, ai_system_prompt)
#     if error:
#         st.session_state.agent = None
#         st.session_state.agent_status = f"Error: {error}"
#         st.session_state.agent_prompt = None
#     else:
#         agent, status, agent_prompt = create_langchain_agent(agent_name, ai_system_prompt)
#         st.session_state.agent = agent
#         st.session_state.agent_status = status
#         st.session_state.agent_prompt = agent_prompt

# # Embedding logic
# if embed_btn and uploaded_files:
#     vectorstore = process_embeddings(uploaded_files)
#     if vectorstore:
#         st.session_state.vectorstore = vectorstore
#         st.sidebar.success("Embeddings processed successfully.")
#     else:
#         st.sidebar.error("Failed to process embeddings.")

# # Main chat area
# st.header("Chat with Agent")
# if st.session_state.agent_status == "Ready" and st.session_state.agent:
#     user_input = st.text_input("Your message:")
#     if st.button("Send") and user_input:
#         try:
#             context = ""
#             if st.session_state.vectorstore:
#                 docs = st.session_state.vectorstore.similarity_search(user_input, k=2)
#                 context = "\n".join([d.page_content for d in docs])
#             prompt = f"{st.session_state.agent_prompt}\nContext: {context}\nUser: {user_input}"
#             response = st.session_state.agent.invoke(prompt).content
#             st.session_state.chat_history.append((user_input, response))
#         except Exception as e:
#             logger.error(f"Chat error: {e}", exc_info=True)
#             st.error(f"Agent error: {str(e)}")

#     # Display chat history with tabular output
#     for i, (q, a) in enumerate(st.session_state.chat_history):
#         st.markdown(f"**You:** {q}")
#         try:
#             # Try to parse response as CSV for tabular display
#             df = pd.read_csv(io.StringIO(a))
#             st.dataframe(df)
#         except Exception:
#             # If parsing fails, display raw text
#             st.markdown(f"**Agent:** {a}")
# else:
#     st.info("Create an agent to start chatting.")

# # Usage Example
# st.sidebar.markdown("""
# **Usage Example:**
# 1. Enter agent name and system prompt, click 'Create Agent'.
# 2. (Optional) Upload text files and click 'Process Embeddings'.
# 3. Chat with the agent in the main area.
# """)

# # Security notes
# st.sidebar.markdown("""
# **Security:**
# - API keys are loaded from .env
# - Uploaded files are validated
# - Sensitive data is never exposed
# """)
