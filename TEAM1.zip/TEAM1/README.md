# LangChain Streamlit Agent Application

## Overview
This application is a production-ready Streamlit app that allows users to create and interact with custom AI agents powered by LangChain and OpenAI. It supports document embedding for Retrieval-Augmented Generation (RAG) and provides a secure, user-friendly chat interface.

---

## Features
- **Agent Creation:**
  - Enter an agent name and a custom AI system prompt in the sidebar.
  - Click "Create Agent" to instantiate a LangChain agent using your prompt and credentials.
- **Document Embedding (Optional):**
  - Upload one or more `.txt` files to embed their contents using OpenAIEmbeddings.
  - Embedded documents are stored in a FAISS vectorstore for context retrieval.
- **Agent Status Indicator:**
  - Displays "Ready" or "Error" based on agent creation and configuration.
- **Chat Interface:**
  - Chat with your agent in the main area.
  - If documents are embedded, the agent retrieves relevant context for each query.
- **Secure Configuration:**
  - API keys and model names are loaded from a `.env` file.
  - Sensitive data is never exposed in logs or UI.
- **Robust Error Handling:**
  - All critical operations are wrapped in try-except blocks with user feedback and logging.
- **Session State Management:**
  - Streamlit session state is used to persist agent, vectorstore, chat history, and prompts.

---

## Setup Instructions

### 1. Prerequisites
- Python 3.10 or newer
- Windows OS (recommended, but cross-platform compatible)

### 2. Clone the Repository
```powershell
git clone <your-repo-url>
cd event_day_code
```

### 3. Create and Activate a Virtual Environment
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

### 4. Install Dependencies
```powershell
pip install -U streamlit python-dotenv langchain langchain-community langchain-openai httpx
```

### 5. Configure Environment Variables
Create a `.env` file in the root directory with the following keys:
```
BASE_URL=https://genailab.tcs.in
AI_MODEL=azure/genailab-maas-gpt-35-turbo
AI_API_KEY=<your-ai-api-key>
EMBEDDING_MODEL=azure/genailab-maas-text-embedding-3-large
EMBEDDING_API_KEY=<your-embedding-api-key>
```

### 6. Run the Application
```powershell
streamlit run app.py
```

---

## Usage Guide

### Agent Creation
1. Enter a unique agent name and a detailed system prompt in the sidebar.
2. Click **Create Agent**. The status indicator will show "Ready" if successful, or display an error message.

### Document Embedding (Optional)
1. Upload one or more `.txt` files using the sidebar uploader.
2. Click **Process Embeddings**. If successful, documents are embedded and available for context retrieval during chat.

### Chatting with the Agent
1. Type your message in the main chat input box.
2. Click **Send**. The agent will respond, optionally using context from embedded documents.
3. Chat history is displayed below the input box.

---

## Security Considerations
- **API Keys:** Never hardcoded; always loaded from `.env`.
- **Input Validation:** All user inputs are validated for length and presence.
- **Error Handling:** All exceptions are logged with full context; users receive clear error messages.
- **Sensitive Data:** Never exposed in logs or UI.
- **SSL Verification:** HTTP client disables SSL verification only if required (see `httpx.Client(verify=False)`).

---

## Code Structure
- `app.py`: Main Streamlit application.
- `.env`: Environment variables for API keys and model names.
- `examples/`: Example scripts for using LangChain and OpenAI integrations.
- `application.prd.md`: Project requirements and specifications.

---

## Troubleshooting
- **Import Errors:** Ensure you are running in the correct virtual environment and all dependencies are installed.
- **Deprecation Warnings:** Update imports as per LangChain documentation. Use `langchain_openai` for OpenAI integrations and `langchain_community` for vectorstores/loaders.
- **SSL Errors:** If you encounter SSL certificate errors, check your network and consider setting `verify=False` in the HTTP client (not recommended for production).
- **Agent Creation Errors:** Ensure your API keys and model names are correct in `.env`.

---

## Example `.env` File
```
BASE_URL=https://genailab.tcs.in
AI_MODEL=azure/genailab-maas-gpt-35-turbo
AI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxx
EMBEDDING_MODEL=azure/genailab-maas-text-embedding-3-large
EMBEDDING_API_KEY=sk-yyyyyyyyyyyyyyyyyyyy
```

---

## References & Further Reading
- [LangChain Documentation](https://python.langchain.com/)
- [Streamlit Documentation](https://docs.streamlit.io/)
- [OpenAI API Reference](https://platform.openai.com/docs/api-reference)

---

## License
This project is provided for educational and demonstration purposes. Please review and comply with all third-party API terms and licensing requirements.
