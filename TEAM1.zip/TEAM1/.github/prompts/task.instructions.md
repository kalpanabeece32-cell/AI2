# Task

Create a streamlit application in python with below features

- application will have a left side activity bar were Agent name and an AI system prompt will be entered, upon clicking create agent button will create a langchain based agent using the name and system prompt
- We will have one more area to upload/select multiple files that will be uploaded and processed for embedding into `OpenAIEmbeddings`; this will be an optional step 
- we will have an indicator status called "Agent Status" were agent Ready, Error based on the above given details while creating agent
- have a chat area at the middle to chat with that agent
- the `.env` file in the root folder has `AI_API_KEY` and `EMBEDDING_API_KEY` which can be used in `ChatOpenAI` and `OpenAIEmbeddings` inplace of `api_key`; it also has preferred `AI_MODEL` and `EMBEDDING_MODEL`
- the file `exampels/test_llm.py` and `examples/testing.py` has basic example on how to use the keys with  