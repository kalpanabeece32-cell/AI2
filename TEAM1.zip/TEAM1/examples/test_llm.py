from langchain_openai import ChatOpenAI
import httpx
import logging
from pprint import pprint

# Configure logging
logging.basicConfig(level=logging.INFO)

# Create an HTTP client that skips SSL verification (only use this if necessary)
client = httpx.Client(verify=False)

# Initialize the LLM
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-OcmEGctbS7Lc9EKNnh9Ysw",  # Replace with your actual key
    http_client=client
)

try:
    # Send a prompt
    response = llm.invoke("Hi")
    logging.info("LLM response received successfully.")
    print("\n--- LLM Response (Pretty Printed) ---")
    pprint({
        "content": response.content,
        "additional_kwargs": response.additional_kwargs,
        "response_metadata": response.response_metadata,
        "id": response.id,
        "usage_metadata": response.usage_metadata
    })
    print("--- End of Response ---\n")
except Exception as exc:
    logging.error(f"Error invoking LLM: {exc}", exc_info=True)
    print("An error occurred while invoking the LLM. Please check logs for details.")
