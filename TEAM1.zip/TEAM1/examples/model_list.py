from dotenv import load_dotenv
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
import httpx
import os
import logging
from typing import List

load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Retrieve API key securely
OPENAI_API_KEY = os.getenv('EMBEDDING_API_KEY')
if not OPENAI_API_KEY:
    logger.error('OPENAI_API_KEY environment variable not set.')
    raise EnvironmentError('OPENAI_API_KEY environment variable not set.')

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-gpt-35-turbo",
    api_key="sk-zkYSx0gbIE5r3A8xhFKeWw",  # Replace with your actual API key
    http_client=client
)
              
embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key="sk-20J3Dwzr9M1BquOqF-f4QA",  # Replace with your actual API key
    http_client=client
)

# Function to get available models from OpenAI/Azure endpoint

def get_embedding_models(base_url: str, api_key: str) -> List[str]:
    """
    Retrieve the list of available embedding models from the OpenAI/Azure endpoint.

    Args:
        base_url (str): The base URL of the OpenAI/Azure endpoint.
        api_key (str): The API key for authentication.

    Returns:
        List[str]: List of embedding model names.
    """
    try:
        response = client.get(
            f"{base_url}/openai/models",
            headers={"api-key": api_key}
        )
        response.raise_for_status()
        data = response.json()
        # Filter for embedding models (example: contains 'embedding' in name)
        embedding_models = [
            model['id'] for model in data.get('data', [])
            if 'embedding' in model.get('id', '').lower()
        ]
        logger.info(f"Found {len(embedding_models)} embedding models.")
        return embedding_models
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error: {e.response.status_code} - {e.response.text}")
        return []
    except Exception as e:
        logger.exception("Failed to retrieve embedding models.")
        return []

if __name__ == "__main__":
    BASE_URL = "https://genailab.tcs.in"
    models = get_embedding_models(BASE_URL, "sk-gO0UmJJp5O5SGqxfozs2rA")
    print("Available embedding models:")
    for m in models:
        print(f"- {m}")

#DON'T EDIT THIS FILE


# [SSLError] [SSL: CERTIFICATE_VERIFY_FAILED] 
# https://stackoverflow.com/questions/76106366/how-to-use-tiktoken-in-offline-mode-computer